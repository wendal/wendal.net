# Memcached 2.1.14 for windows x64 , cgywin

Compile by wendal
http://wendal.net/2015/04/27.html